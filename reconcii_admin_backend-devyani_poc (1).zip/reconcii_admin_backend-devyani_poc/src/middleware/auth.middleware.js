const jwt = require("jsonwebtoken");
const db = require("../models");
const verifyToken = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(" ")[1];

    if (!token) {
      return res.status(401).json({ message: "No token provided" });
    }

    // Buffer.from(process.env.JWT_SECRET, "base64")
    const decoded = jwt.verify(
      token,
      Buffer.from(process.env.JWT_SECRET, "base64")
    );

    let user = {};
    if (decoded?.jti) {
      user = await db.user_details.findOne({
        where: { username: decoded?.jti },
      });
    } else {
      user = await db.user_details.findByPk(decoded.id);
    }

    if (!user) {
      return res.status(401).json({ message: "User not found" });
    }

    // if (!user.isActive) {
    //   return res.status(401).json({ message: "User is inactive" });
    // }

    req.user = user;
    next();
  } catch (error) {
    console.log("error", JSON.stringify(error));
    return res.status(401).json({ message: "Invalid token" });
  }
};

const isAdmin = (req, res, next) => {
  next();
  // if (req.user && req.user.role === "admin") {
  //   next();
  // } else {
  //   res.status(403).json({ message: "Require Admin Role!" });
  // }
};

module.exports = {
  verifyToken,
  isAdmin,
};
